#  -------------------------------
#  Difficult Rocket
#  Copyright © 2021 by shenjackyuanjie
#  All rights reserved
#  -------------------------------

"""
writen by shenjackyuanjie
mail:   3695888@qq.com
github: @shenjackyuanjie
gitee:  @shenjackyuanjie
"""


class Delivery:
    def __init__(self):
        # bool
        self.using = False
        self.read = False
        self.key_board_get = False
        # dic
        self.ship_info = {}
        self.planet_system = {}
        self.main_ship_parts = {}
        self.this_planet_info = {}
        self.back_ground_element = {}
        # value
        self.back_ground_image = ''
